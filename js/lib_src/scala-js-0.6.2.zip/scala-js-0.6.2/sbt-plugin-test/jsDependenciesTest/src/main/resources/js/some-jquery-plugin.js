// js/some-jquery-plugin.js
