// js/foo.js
