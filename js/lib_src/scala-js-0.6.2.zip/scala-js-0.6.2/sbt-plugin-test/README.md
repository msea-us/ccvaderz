This is a standalone SBT project to test the Scala.js SBT plugin as it
will be used by the users. (Through normal SBT dependency
management). This needs the Scala.js artifacts to be published
locally.

It has two subprojects, to test Scala.js with and without DOM. Both
subprojects have a main class and a test.
