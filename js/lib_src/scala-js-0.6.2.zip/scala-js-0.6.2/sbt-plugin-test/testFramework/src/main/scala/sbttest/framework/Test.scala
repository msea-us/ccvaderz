package sbttest.framework

import scala.scalajs.js.annotation.JSExportDescendentClasses

@JSExportDescendentClasses
class Test
