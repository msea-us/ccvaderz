package sbttest.multitest.test

import sbttest.framework.Test

class TrivialTest extends Test
