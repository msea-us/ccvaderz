package sbttest.multitest

object Lib {
  def sq(x: Int): Int = x * x
}
