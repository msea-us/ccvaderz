package java.lang

trait AutoCloseable {
  def close(): Unit
}
