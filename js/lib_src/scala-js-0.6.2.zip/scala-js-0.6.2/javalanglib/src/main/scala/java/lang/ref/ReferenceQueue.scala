package java.lang.ref

class ReferenceQueue[T >: Null <: AnyRef]
