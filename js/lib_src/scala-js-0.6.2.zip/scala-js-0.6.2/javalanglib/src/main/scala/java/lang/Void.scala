package java.lang

final class Void private {}

object Void {
  final val TYPE = classOf[scala.Unit]
}
