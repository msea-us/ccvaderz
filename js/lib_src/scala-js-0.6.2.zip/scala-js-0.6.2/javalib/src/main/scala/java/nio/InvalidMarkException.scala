package java.nio

class InvalidMarkException extends IllegalStateException
