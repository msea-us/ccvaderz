package java.nio

class BufferOverflowException extends RuntimeException
