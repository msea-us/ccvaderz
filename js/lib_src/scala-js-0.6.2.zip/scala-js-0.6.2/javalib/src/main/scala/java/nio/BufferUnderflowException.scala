package java.nio

class BufferUnderflowException extends RuntimeException
