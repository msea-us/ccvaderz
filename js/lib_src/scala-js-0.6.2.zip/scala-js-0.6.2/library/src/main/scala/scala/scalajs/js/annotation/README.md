**Attention**: Some files in here are also published in the Scala.js stubs JVM library (see the stubs project in the Scala.js build).

If you add (or rename) a file, make sure the files in the stubs project are up to date.
